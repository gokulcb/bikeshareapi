def test_make_prediction_empty_input():
    """Test make_prediction with empty input data."""
    data_in = {}

    result = make_prediction(input_data=data_in)

    assert result["predictions"] is None
    assert result["errors"] is not None
    assert len(result["errors"]) > 0

def test_make_prediction_missing_column():
    """Test make_prediction with missing column input data."""
    data_in = {
        'dteday': ["2012-11-05"], 'season': ["winter"], 'hr': ["2am"], 'holiday': ["No"],
        'weekday': ["Mon"], 'workingday': ["Yes"], 'weathersit': ["Mist"],
        'atemp': [3.0014], 'hum': [49.0], 'windspeed': [19.0012],
        'yr': ["2012"]
    }

    result = make_prediction(input_data=data_in)

    assert result["predictions"] is None
    assert result["errors"] is not None
    assert len(result["errors"]) > 0

