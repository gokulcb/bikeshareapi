
"""
Note: These tests will fail if you have not first trained the model.
"""
import sys
from pathlib import Path
file = Path(__file__).resolve()
parent, root = file.parent, file.parents[1]
sys.path.append(str(root))

import numpy as np
import pandas as pd
import pytest as pytest
from bikeshare_model.config.core import config
from bikeshare_model.processing.features import Mapper, WeekdayImputer


month_mappings = {
    "January": 0,
    "February": 1,
    "December": 2,
    "March": 3,
    "November": 4,
    "April": 5,
    "October": 6,
    "May": 7,
    "September": 8,
    "June": 9,
    "July": 10,
    "August": 11,
}

def test_mapper_transform():
    data = pd.DataFrame({"month": ["January", "March", "December", "July"]})
    mapper = Mapper(variables="month", mappings=month_mappings)
    transformed_data = mapper.transform(data)
    expected_data = pd.DataFrame({"month": [0, 3, 2, 10]})
    pd.testing.assert_frame_equal(transformed_data, expected_data)

def test_mapper_fit_transform():
    data = pd.DataFrame({"month": ["January", "March", "December", "July"]})
    mapper = Mapper(variables="month", mappings=month_mappings)
    transformed_data = mapper.fit_transform(data)
    expected_data = pd.DataFrame({"month": [0, 3, 2, 10]})
    pd.testing.assert_frame_equal(transformed_data, expected_data)

def test_mapper_invalid_variable_type():
    with pytest.raises(ValueError):
        Mapper(variables=["month"], mappings=month_mappings)

def test_mapper_empty_dataframe():
    data = pd.DataFrame({"month": []})
    mapper = Mapper(variables="month", mappings=month_mappings)
    transformed_data = mapper.transform(data)
    expected_data = pd.DataFrame({"month": []},dtype='int64')
    pd.testing.assert_frame_equal(transformed_data, expected_data)

def test_mapper_correct_column_type():
    data = pd.DataFrame({"month": ["January", "March"]})
    mapper = Mapper(variables="month", mappings=month_mappings)
    transformed_data = mapper.transform(data)
    assert transformed_data['month'].dtype == 'int64'
    
    
def test_weekday_imputer_valid_input():
    data = pd.DataFrame({
        'dteday': ['2023-10-26', '2023-10-27', '2023-10-28', '2023-10-29'],
        'weekday': ['Thu', None, None, 'Sun']
    })
    imputer = WeekdayImputer(variables='weekday')
    transformed_data = imputer.fit_transform(data)
    expected_data = pd.DataFrame({
        'dteday': pd.to_datetime(['2023-10-26', '2023-10-27', '2023-10-28', '2023-10-29']),
        'weekday': ['Thu', 'Fri', 'Sat', 'Sun']
    })
    pd.testing.assert_frame_equal(transformed_data, expected_data)

def test_weekday_imputer_invalid_variable_type():
    with pytest.raises(ValueError):
        WeekdayImputer(variables=['weekday'])

def test_weekday_imputer_no_missing_values():
    data = pd.DataFrame({
        'dteday': ['2023-10-26', '2023-10-27', '2023-10-28', '2023-10-29'],
        'weekday': ['Thu', 'Fri', 'Sat', 'Sun']
    })
    imputer = WeekdayImputer(variables='weekday')
    transformed_data = imputer.fit_transform(data)
    pd.testing.assert_frame_equal(transformed_data, data.astype({'dteday':'datetime64[ns]'}))

def test_weekday_imputer_custom_date_column():
    data = pd.DataFrame({
        'date': ['2023-10-26', '2023-10-27', '2023-10-28', '2023-10-29'],
        'day': [None, None, None, None]
    })
    imputer = WeekdayImputer(variables='day', date_column='date')
    transformed_data = imputer.fit_transform(data)
    expected_data = pd.DataFrame({
        'date': pd.to_datetime(['2023-10-26', '2023-10-27', '2023-10-28', '2023-10-29']),
        'day': ['Thu', 'Fri', 'Sat', 'Sun']
    })
    pd.testing.assert_frame_equal(transformed_data, expected_data)