"""
Note: These tests will fail if you have not first trained the model.
"""
import sys
from pathlib import Path
file = Path(__file__).resolve()
parent, root = file.parent, file.parents[1]
sys.path.append(str(root))

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score

from bikeshare_model.predict import make_prediction
from bikeshare_model.processing.validation import validate_inputs
from bikeshare_model.config.core import config


def test_make_prediction_valid_input():
    """Test make_prediction with valid input data."""

    data_in = {
        'dteday': ["2012-11-05"], 'season': ["winter"], 'hr': ["2am"], 'holiday': ["No"],
        'weekday': ["Mon"], 'workingday': ["Yes"], 'weathersit': ["Mist"], 'temp': [6.10],
        'atemp': [3.0014], 'hum': [49.0], 'windspeed': [19.0012],
        'casual': [5], 'registered': [93]
    }
    
    validated_data, errors = validate_inputs(input_df=pd.DataFrame(data_in))
    
    validated_data=validated_data.reindex(columns=config.model_config_.features)
    
    print()
    print("test_make_prediction_valid_input: VALIDATED DATA")
    print(validated_data)

    result = make_prediction(input_data=validated_data)
    
    print()
    print("test_make_prediction_valid_input: RESULT")
    print(result)

    assert result["predictions"] is not None
    assert result["errors"] is None

def test_make_prediction_invalid_input():
    """Test make_prediction with invalid input data."""

    data_in = {
        'dteday': ["2012-11-05"], 'season': ["winter"], 'hr': ["2am"], 'holiday': ["No"],
        'weekday': ["Mon"], 'workingday': ["Yes"], 'weathersit': ["Mist"], 'temp': ["invalid"],
        'atemp': [3.0014], 'hum': [49.0], 'windspeed': [19.0012],
        'casual': [5], 'registered': [93]
    }
    
    validated_data, errors = validate_inputs(input_df=pd.DataFrame(data_in))

    print()
    print("test_make_prediction_invalid_input: ERROR DETAILS")
    print(errors)
    assert errors is not None

